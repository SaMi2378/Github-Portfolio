import java.util.LinkedList;
import java.util.Iterator;

/**
 * This class represents a flight queue in a flight controller application.
 * It manages a list of flights and provides operations to manipulate the queue.
 */
public class FlightQueue {
    // Attributes
    private LinkedList<Flight> flights;

    /**
     * Default constructor that initializes the FlightQueue with an empty list of flights.
     */
    public FlightQueue() {
        flights = new LinkedList<>();
    }

    /**
     * Inserts a flight into the queue with no priority order.
     *
     * @param f The flight to be added to the queue.
     */
    public void joinQueue(Flight f) {
        flights.add(f);
    }

    /**
     * Lands a flight by removing it from the front of the queue.
     */
    public void landFlight() {
        if (!flights.isEmpty()) {
            flights.remove();
        }
    }

    /**
     * Returns the number of aircraft in the queue.
     *
     * @return The number of flights in the queue.
     */
    public int size() {
        return flights.size();
    }

    /**
     * Lands all flights, leaving the queue empty.
     * Uses an Iterator to iterate through the queue and remove flights.
     */
    public void clear() {
        Iterator<Flight> iterator = flights.iterator();
        while (iterator.hasNext()) {
            iterator.next();
            iterator.remove();
        }
    }

    /**
     * Displays a list of flights in the queue using a for-each loop.
     */
    public void display() {
        for (Flight f : flights) {
            System.out.println(f.toString());
        }
    }
}

