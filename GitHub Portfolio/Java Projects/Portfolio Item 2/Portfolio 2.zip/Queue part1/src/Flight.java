/**
 * This class represents a flight with a unique identifier and priority level.
 */
public class Flight {
    // Attributes
    private String flightID;
    private int priority;

    /**
     * Default constructor that initializes the Flight with default values.
     */
    public Flight() {
        this.flightID = "DefaultID";
        this.priority = 1;
    }

    /**
     * Parameter constructor that sets the attribute values based on the provided parameters.
     *
     * @param flightID The unique identifier for the flight.
     * @param priority The priority level of the flight (1 - 9).
     */
    public Flight(String flightID, int priority) {
        this.flightID = flightID;
        this.priority = priority;
    }

    /**
     * Setter method for setting the flight ID.
     *
     * @param flightID The unique identifier for the flight.
     */
    public void setFlightID(String flightID) {
        this.flightID = flightID;
    }

    /**
     * Setter method for setting the priority level of the flight.
     *
     * @param priority The priority level of the flight (1 - 9).
     */
    public void setPriority(int priority) {
        this.priority = priority;
    }

    /**
     * Getter method for retrieving the flight ID.
     *
     * @return The flight ID.
     */
    public String getFlightID() {
        return flightID;
    }

    /**
     * Getter method for retrieving the priority level of the flight.
     *
     * @return The priority level of the flight.
     */
    public int getPriority() {
        return priority;
    }

    /**
     * Returns a suitably formatted string of the attribute values.
     *
     * @return A string representation of the Flight object.
     */
    @Override
    public String toString() {
        return "Flight ID: " + flightID + ", Priority: " + priority;
    }
}
