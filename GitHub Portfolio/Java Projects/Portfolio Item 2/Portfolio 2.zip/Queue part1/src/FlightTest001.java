public class FlightTest001 {
    public static void main(String[] args) {
        // Create a FlightQueue
        FlightQueue flightQueue = new FlightQueue();

        // Create and add flights to the queue without maintaining priority order
        Flight flight1 = new Flight("BA378", 5);
        Flight flight2 = new Flight("LH123", 2);
        Flight flight3 = new Flight("AF456", 8);

        // Join flights to the queue
        flightQueue.joinQueue(flight1);
        flightQueue.joinQueue(flight2);
        flightQueue.joinQueue(flight3);

        // Display the initial state of the queue
        System.out.println("Initial state of the flight queue:");
        flightQueue.display();
        System.out.println("Number of flights in the queue: " + flightQueue.size());
        System.out.println();

        // Land a flight and display the updated state
        System.out.println("Landing one flight...");
        flightQueue.landFlight();
        System.out.println("Updated state of the flight queue:");
        flightQueue.display();
        System.out.println("Number of flights in the queue: " + flightQueue.size());
        System.out.println();

        // Clear the queue and display the final state
        System.out.println("Clearing the flight queue...");
        flightQueue.clear();
        System.out.println("Final state of the flight queue:");
        flightQueue.display();
        System.out.println("Number of flights in the queue: " + flightQueue.size());
    }
}

