import java.util.PriorityQueue;

/**
 * This class represents a priority flight queue using java.util.PriorityQueue.
 * Flights are automatically ordered based on their priority.
 *
 * @author Sami Ullah
 * @version 1.0
 */
public class JavaPriorityFlightQueue {
    // Attributes
    private PriorityQueue<Flight> flights;

    /**
     * Default constructor that initializes the priority queue.
     */
    public JavaPriorityFlightQueue() {
        flights = new PriorityQueue<>((f1, f2) -> Integer.compare(f2.getPriority(), f1.getPriority()));
    }

    /**
     * Adds a flight to the priority queue.
     *
     * @param flight The flight to be added to the queue.
     */
    public void joinQueue(Flight flight) {
        flights.add(flight);
    }

    /**
     * Lands the highest priority flight from the priority queue.
     */
    public void landFlight() {
        if (!flights.isEmpty()) {
            flights.poll();  // Remove the highest priority flight
        }
    }

    /**
     * Returns the number of aircraft in the priority queue.
     *
     * @return The number of flights in the queue.
     */
    public int size() {
        return flights.size();
    }

    /**
     * Lands all flights, leaving the priority queue empty.
     */
    public void clear() {
        flights.clear();
    }

    /**
     * Displays a list of flights in the priority queue.
     */
    public void display() {
        for (Flight f : flights) {
            System.out.println(f.toString());
        }
    }
}
