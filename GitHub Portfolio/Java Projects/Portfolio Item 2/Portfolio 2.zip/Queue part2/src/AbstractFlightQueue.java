import java.util.LinkedList;

/**
 * An abstract class representing a flight queue.
 * Subclasses must provide specific implementations for landing flights.
 */
public abstract class AbstractFlightQueue {
    // Attributes
    protected LinkedList<Flight> flights;

    /**
     * Default constructor that initializes the flight queue with an empty list of flights.
     */
    public AbstractFlightQueue() {
        flights = new LinkedList<>();
    }

    /**
     * Inserts a flight into the queue.
     *
     * @param flight The flight to be added to the queue.
     */
    public abstract void joinQueue(Flight flight);

    /**
     * Lands the highest priority flight from the queue.
     * Subclasses must implement this method to provide specific landing behavior.
     */
    public abstract void landFlight();

    /**
     * Returns the number of aircraft in the queue.
     *
     * @return The number of flights in the queue.
     */
    public int size() {
        return flights.size();
    }

    /**
     * Lands all flights, leaving the queue empty.
     */
    public void clear() {
        flights.clear();
    }

    /**
     * Displays a list of flights in the queue.
     */
    public void display() {
        for (Flight f : flights) {
            System.out.println(f.toString());
        }
    }
}
