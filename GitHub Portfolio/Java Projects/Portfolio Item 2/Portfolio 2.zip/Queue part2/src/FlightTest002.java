public class FlightTest002 {
    public static void main(String[] args) {
        // Create instances of all three types of FlightQueue
        AbstractFlightQueue priorityQueue1 = new PriorityFlightQueue1();
        AbstractFlightQueue priorityQueue2 = new PriorityFlightQueue2();
        AbstractFlightQueue normalQueue = new NormalFlightQueue();

        // Create and add flights to the queues
        Flight flight1 = new Flight("BA378", 5);
        Flight flight2 = new Flight("LH123", 2);
        Flight flight3 = new Flight("AF456", 8);

        // Test PriorityFlightQueue1
        priorityQueue1.joinQueue(flight1);
        priorityQueue1.joinQueue(flight2);
        priorityQueue1.joinQueue(flight3);

        System.out.println("PriorityFlightQueue1:");
        priorityQueue1.display();
        System.out.println("Number of flights: " + priorityQueue1.size());
        priorityQueue1.landFlight();
        System.out.println("After landing one flight:");
        priorityQueue1.display();
        System.out.println("Number of flights: " + priorityQueue1.size());
        priorityQueue1.clear();
        System.out.println("After clearing the queue:");
        priorityQueue1.display();
        System.out.println();

        // Test PriorityFlightQueue2
        priorityQueue2.joinQueue(flight1);
        priorityQueue2.joinQueue(flight2);
        priorityQueue2.joinQueue(flight3);

        System.out.println("PriorityFlightQueue2:");
        priorityQueue2.display();
        System.out.println("Number of flights: " + priorityQueue2.size());
        priorityQueue2.landFlight();
        System.out.println("After landing one flight:");
        priorityQueue2.display();
        System.out.println("Number of flights: " + priorityQueue2.size());
        priorityQueue2.clear();
        System.out.println("After clearing the queue:");
        priorityQueue2.display();
        System.out.println();

        // Test NormalFlightQueue
        normalQueue.joinQueue(flight1);
        normalQueue.joinQueue(flight2);
        normalQueue.joinQueue(flight3);

        System.out.println("NormalFlightQueue:");
        normalQueue.display();
        System.out.println("Number of flights: " + normalQueue.size());
        normalQueue.landFlight();
        System.out.println("After landing one flight:");
        normalQueue.display();
        System.out.println("Number of flights: " + normalQueue.size());
        normalQueue.clear();
        System.out.println("After clearing the queue:");
        normalQueue.display();
    }
}
