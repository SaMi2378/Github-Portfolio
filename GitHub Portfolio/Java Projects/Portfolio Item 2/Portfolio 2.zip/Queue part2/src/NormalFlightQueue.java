/**
 * A concrete subclass of AbstractFlightQueue representing a normal flight queue without priority order.
 * Flights are landed in the order they joined the queue.
 */
public class NormalFlightQueue extends AbstractFlightQueue {

    /**
     * Inserts a flight into the normal queue without maintaining priority order.
     *
     * @param flight The flight to be added to the queue.
     */
    @Override
    public void joinQueue(Flight flight) {
        flights.add(flight);
    }

    /**
     * Lands the next flight in the normal queue.
     */
    @Override
    public void landFlight() {
        if (!flights.isEmpty()) {
            flights.removeFirst();  // Remove the next flight in the order
        }
    }
}
