/**
 * Another concrete subclass of AbstractFlightQueue representing a priority flight queue.
 * Flights are added by iterating through the sorted loop to find the correct point to insert.
 */
public class PriorityFlightQueue2 extends AbstractFlightQueue {

    /**
     * Adds a flight by iterating through the sorted loop to find the correct point to insert.
     *
     * @param flight The flight to be added to the queue.
     */
    @Override
    public void joinQueue(Flight flight) {
        int index = 0;
        while (index < flights.size() && flight.getPriority() >= flights.get(index).getPriority()) {
            index++;
        }
        flights.add(index, flight);
    }

    /**
     * Lands the lowest priority flight from the priority queue.
     */
    @Override
    public void landFlight() {
        if (!flights.isEmpty()) {
            flights.removeLast();  // Remove the lowest priority flight
        }
    }
}
