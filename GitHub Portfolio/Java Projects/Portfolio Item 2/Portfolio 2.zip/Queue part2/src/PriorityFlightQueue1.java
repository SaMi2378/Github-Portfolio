import java.util.Collections;

/**
 * A concrete subclass of AbstractFlightQueue representing a priority flight queue.
 * Flights are added to the back of the queue and then sorted by priority.
 */
public class PriorityFlightQueue1 extends AbstractFlightQueue {

    /**
     * Adds a flight to the back of the queue and then sorts the whole queue by priority.
     *
     * @param flight The flight to be added to the queue.
     */
    @Override
    public void joinQueue(Flight flight) {
        flights.add(flight);
        Collections.sort(flights, (f1, f2) -> Integer.compare(f2.getPriority(), f1.getPriority()));
    }

    /**
     * Lands the highest priority flight from the priority queue.
     */
    @Override
    public void landFlight() {
        if (!flights.isEmpty()) {
            flights.removeFirst();  // Remove the highest priority flight
        }
    }
}
