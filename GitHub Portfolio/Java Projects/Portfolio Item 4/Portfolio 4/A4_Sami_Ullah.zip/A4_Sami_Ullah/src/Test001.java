/**
 * @author Sami Ullah
 * @version 1.0
 */


/**
 * A test class to demonstrate adding information for 3 cars into the DVLA HashMap
 * and calling the showAllCars method.
 */
public class Test001 {
    public static void main(String[] args) {
        // Creating DVLA object
        DVLA dvla = new DVLA();

        // Creating Car objects
        Car car1 = new Car("Toyota", "Camry", "Blue");
        Car car2 = new Car("Honda", "Civic", "Silver");
        Car car3 = new Car("Ford", "Focus", "Red");

        // Creating Keeper objects
        Keeper keeper1 = new Keeper("John", "Doe", new Address("123 Main St", "City1", "12345"));
        Keeper keeper2 = new Keeper("Jane", "Smith", new Address("456 Oak St", "City2", "67890"));
        Keeper keeper3 = new Keeper("Bob", "Johnson", new Address("789 Pine St", "City3", "54321"));

        // Creating RegNo objects
        RegNo regNo1 = new RegNo("ABC123");
        RegNo regNo2 = new RegNo("XYZ789");
        RegNo regNo3 = new RegNo("DEF456");

        // Adding information for 3 cars to the DVLA HashMap
        dvla.addCarInfo(regNo1, car1, keeper1);
        dvla.addCarInfo(regNo2, car2, keeper2);
        dvla.addCarInfo(regNo3, car3, keeper3);

        // Calling the showAllCars method to display information
        dvla.showAllCars();
    }
}
