import java.io.Serializable;
import java.util.Objects;

/**
 * @author Sami Ullah
 * @version 1.0
 */

/**
 * Represents a car registration number.
 * Implements Comparable for natural ordering.
 *
 * 
 */
public class RegNo implements  Comparable<RegNo>, Serializable {
    private final String regNo;

    /**
     * Constructs a RegNo object with the specified registration number.
     *
     * @param regNo The registration number.
     */
    public RegNo(String regNo) {
        this.regNo = regNo;
    }

    /**
     * Gets the registration number.
     *
     * @return The registration number.
     */
    public String getRegNo() {
        return regNo;
    }

    /**
     * Compares this registration number with another for ordering.
     * Natural ordering is based on the lexicographical order of the registration numbers.
     *
     * @param otherRegNo The registration number to be compared.
     * @return A negative integer, zero, or a positive integer as this registration number is less than, equal to,
     *         or greater than the specified registration number.
     */
    @Override
    public int compareTo(RegNo otherRegNo) {
        return this.regNo.compareTo(otherRegNo.regNo);
    }

    /**
     * Checks if this registration number is equal to another object.
     *
     * @param obj The object to compare with.
     * @return True if the objects are equal, false otherwise.
     */
    @Override
    public boolean equals(Object obj) {
        if (this == obj) return true;
        if (obj == null || getClass() != obj.getClass()) return false;
        RegNo regNo1 = (RegNo) obj;
        return Objects.equals(regNo, regNo1.regNo);
    }

    /**
     * Generates a hash code for this registration number.
     *
     * @return The hash code.
     */
    @Override
    public int hashCode() {
        return Objects.hash(regNo);
    }

    /**
     * Returns a string representation of the registration number.
     *
     * @return A string representation of the registration number.
     */
    @Override
    public String toString() {
        return regNo;  // Provide a meaningful representation for toString
    }
}
