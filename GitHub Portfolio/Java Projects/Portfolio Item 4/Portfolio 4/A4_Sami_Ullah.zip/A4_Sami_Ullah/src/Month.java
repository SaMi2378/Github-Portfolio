/**
 * @author Sami Ullah
 * @version 1.0
 */
 
 /**
 * Enum class representing months with associated int values.
 * Provides constants for January to December.
 *
 *
 */
public enum Month {
    JANUARY(1), FEBRUARY(2), MARCH(3), APRIL(4), MAY(5), JUNE(6),
    JULY(7), AUGUST(8), SEPTEMBER(9), OCTOBER(10), NOVEMBER(11), DECEMBER(12);

    private final int monthValue;

    /**
     * Constructs a Month enum constant with the associated int value.
     *
     * @param monthValue The int value of the month.
     */
    Month(int monthValue) {
        this.monthValue = monthValue;
    }

    /**
     * Gets the int value of the month.
     *
     * @return The int value of the month.
     */
    public int getMonthValue() {
        return monthValue;
    }

    /**
     * Gets the Month enum constant based on the provided int value.
     *
     * @param value The int value representing the month.
     * @return The Month enum constant for the specified int value.
     * @throws IllegalArgumentException If no matching Month enum constant is found.
     */
    public static Month fromInt(int value) {
        for (Month month : values()) {
            if (month.getMonthValue() == value) {
                return month;
            }
        }
        throw new IllegalArgumentException("No month with value: " + value);
    }
}
