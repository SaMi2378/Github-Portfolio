import java.io.*;
import java.util.Map;

/**
 * @author Sami Ullah
 * @version 1.0
 */


/**
 * Manages the writing and reading of data to/from a flash drive.
 *
 * This class provides methods to write and read warning and reminder letter data.
 *
 * 
 */
public class FlashDriveManager {
    /**
     * Writes warning and reminder letter data to a flash drive.
     *
     * @param warningLetters Map containing registration numbers and keepers for warning letters.
     * @param reminderLetters Map containing registration numbers and keepers for reminder letters.
     * @param filePath       The path to the flash drive file.
     * @throws IOException If an I/O error occurs during writing.
     */
    public static void writeDataToFlashDrive(Map<RegNo, Keeper> warningLetters,
                                             Map<RegNo, Keeper> reminderLetters,
                                             String filePath) throws IOException {
        try (ObjectOutputStream outputStream = new ObjectOutputStream(new FileOutputStream(filePath))) {
            // Writing warning letters map
            outputStream.writeObject(warningLetters);
            // Writing reminder letters map
            outputStream.writeObject(reminderLetters);
        }
    }

    /**
     * Reads warning and reminder letter data from a flash drive.
     *
     * @param filePath The path to the flash drive file.
     * @return An array containing two maps: warning letters and reminder letters.
     * @throws IOException            If an I/O error occurs during reading.
     * @throws ClassNotFoundException If the class of the serialized object cannot be found.
     */
    public static Map<RegNo, Keeper>[] readDataFromFlashDrive(String filePath) throws IOException, ClassNotFoundException {
        try (ObjectInputStream inputStream = new ObjectInputStream(new FileInputStream(filePath))) {
            // Reading warning letters map
            @SuppressWarnings("unchecked")
            Map<RegNo, Keeper> warningLetters = (Map<RegNo, Keeper>) inputStream.readObject();

            // Reading reminder letters map
            @SuppressWarnings("unchecked")
            Map<RegNo, Keeper> reminderLetters = (Map<RegNo, Keeper>) inputStream.readObject();

            return new Map[]{warningLetters, reminderLetters};
        }
    }
}
