import java.io.Serializable;

/**
 * @author Sami Ullah
 * @version 1.0
 */

/**
 * Represents an address with street, town, and postcode information.
 *
 * 
 */
public class Address  implements Serializable {
    private String street;
    private String town;
    private String postcode;

    /**
     * Constructs an Address object with the specified street, town, and postcode.
     *
     * @param street   The street information.
     * @param town     The town information.
     * @param postcode The postcode information.
     */
    public Address(String street, String town, String postcode) {
        this.street = street;
        this.town = town;
        this.postcode = postcode;
    }

    /**
     * Gets the street information.
     *
     * @return The street information.
     */
    public String getStreet() {
        return street;
    }

    /**
     * Gets the town information.
     *
     * @return The town information.
     */
    public String getTown() {
        return town;
    }

    /**
     * Gets the postcode information.
     *
     * @return The postcode information.
     */
    public String getPostcode() {
        return postcode;
    }

    /**
     * Sets the street information.
     *
     * @param street The new street information.
     */
    public void setStreet(String street) {
        this.street = street;
    }

    /**
     * Sets the town information.
     *
     * @param town The new town information.
     */
    public void setTown(String town) {
        this.town = town;
    }

    /**
     * Sets the postcode information.
     *
     * @param postcode The new postcode information.
     */
    public void setPostcode(String postcode) {
        this.postcode = postcode;
    }

    /**
     * Returns a string representation of the address, including street, town, and postcode.
     *
     * @return A string representation of the address.
     */
    @Override
    public String toString() {
        return "Address{" +
                "street='" + street + '\'' +
                ", town='" + town + '\'' +
                ", postcode='" + postcode + '\'' +
                '}';
    }
}
