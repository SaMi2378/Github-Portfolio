import java.io.IOException;
import java.util.HashMap;
import java.util.Map;

/**
 * A test class to demonstrate writing and reading warning and reminder letter data to/from a flash drive.
 *
 * Implements first-class grade requirements including JavaDoc comments.
 *
 * @author Sami Ullah
 * @version 1.0
 */
public class Test005 {
    /**
     * Main method to execute the test.
     *
     * @param args The command-line arguments (not used).
     */
    public static void main(String[] args) {
        // Creating DVLA object and adding sample data
        DVLA dvla = new DVLA();
        
        // Creating Car objects
        Car car1 = new Car("Toyota", "Camry", "Blue", Month.JANUARY);
        Car car2 = new Car("Honda", "Civic", "Silver", Month.FEBRUARY);
        Car car3 = new Car("Ford", "Focus", "Red", Month.MARCH);

        // Creating Keeper objects
        Keeper keeper1 = new Keeper("John", "Doe", new Address("123 Main St", "City1", "12345"));
        Keeper keeper2 = new Keeper("Jane", "Smith", new Address("456 Oak St", "City2", "67890"));
        Keeper keeper3 = new Keeper("Bob", "Johnson", new Address("789 Pine St", "City3", "54321"));

        // Creating RegNo objects
        RegNo regNo1 = new RegNo("ABC123");
        RegNo regNo2 = new RegNo("XYZ789");
        RegNo regNo3 = new RegNo("DEF456");

        // Adding information for 3 cars to the DVLA HashMap
        dvla.addCarInfo(regNo1, car1, keeper1);
        dvla.addCarInfo(regNo2, car2, keeper2);
        dvla.addCarInfo(regNo3, car3, keeper3);

        

        // Generating sample warning and reminder letters
        Month warningMonth = Month.FEBRUARY;
        Month reminderMonth = Month.MARCH;
        Map<RegNo, Keeper> warningLetters = dvla.getWarningLetters(warningMonth);
        Map<RegNo, Keeper> reminderLetters = dvla.getReminderLetters(reminderMonth);

        // Writing data to the flash drive
        String flashDriveFilePath = "flashDriveData.dat";
        try {
            FlashDriveManager.writeDataToFlashDrive(warningLetters, reminderLetters, flashDriveFilePath);
            System.out.println("Data written to the flash drive successfully.");
        } catch (IOException e) {
            System.err.println("Error writing data to the flash drive: " + e.getMessage());
        }

        // Reading data from the flash drive
        try {
            Map<RegNo, Keeper>[] readData = FlashDriveManager.readDataFromFlashDrive(flashDriveFilePath);
            Map<RegNo, Keeper> readWarningLetters = readData[0];
            Map<RegNo, Keeper> readReminderLetters = readData[1];

            // Displaying the read data
            System.out.println("\nRead Warning Letters:");
            readWarningLetters.forEach((regNo, keeper) ->
                    System.out.println("Registration Number: " + regNo + ", Keeper: " + keeper));

            System.out.println("\nRead Reminder Letters:");
            readReminderLetters.forEach((regNo, keeper) ->
                    System.out.println("Registration Number: " + regNo + ", Keeper: " + keeper));
        } catch (IOException | ClassNotFoundException e) {
            System.err.println("Error reading data from the flash drive: " + e.getMessage());
        }
    }
}
