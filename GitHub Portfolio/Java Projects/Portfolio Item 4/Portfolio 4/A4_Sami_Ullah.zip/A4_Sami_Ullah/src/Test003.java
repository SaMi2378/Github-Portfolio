import java.util.Map;

/**
 * @author Sami Ullah
 * @version 1.0
 */

/**
 * A test class to list all registration numbers and keepers from the DVLA.
 * Implements first-class grade requirements including JavaDoc comments.
 *
 *
 */
public class Test003 {
    /**
     * Main method to execute the test.
     *
     * @param args The command-line arguments (not used).
     */
    public static void main(String[] args) {
        // Creating DVLA object
        DVLA dvla = new DVLA();

        // Creating Car objects
        Car car1 = new Car("Toyota", "Camry", "Blue");
        Car car2 = new Car("Honda", "Civic", "Silver");
        Car car3 = new Car("Ford", "Focus", "Red");

        // Creating Keeper objects
        Keeper keeper1 = new Keeper("John", "Doe", new Address("123 Main St", "City1", "12345"));
        Keeper keeper2 = new Keeper("Jane", "Smith", new Address("456 Oak St", "City2", "67890"));
        Keeper keeper3 = new Keeper("Bob", "Johnson", new Address("789 Pine St", "City3", "54321"));

        // Creating RegNo objects
        RegNo regNo1 = new RegNo("ABC123");
        RegNo regNo2 = new RegNo("XYZ789");
        RegNo regNo3 = new RegNo("DEF456");

        // Adding information for 3 cars to the DVLA HashMap
        dvla.addCarInfo(regNo1, car1, keeper1);
        dvla.addCarInfo(regNo2, car2, keeper2);
        dvla.addCarInfo(regNo3, car3, keeper3);

        // Listing all registration numbers and keepers
        listAllRegistrationNumbersAndKeepers(dvla);
    }

    /**
     * Lists all registration numbers and keepers from the DVLA.
     *
     * @param dvla The DVLA object containing registration numbers and keepers.
     */
    private static void listAllRegistrationNumbersAndKeepers(DVLA dvla) {
        System.out.println("All Registration Numbers and Keepers in DVLA:");
        Map<RegNo, Car> registrationNumberMap = dvla.getRegistrationNumberMap();
        Map<Car, Keeper> carToKeeperMap = dvla.getCarToKeeperMap();

        for (Map.Entry<RegNo, Car> entry : registrationNumberMap.entrySet()) {
            RegNo regNo = entry.getKey();
            Car car = entry.getValue();
            Keeper keeper = carToKeeperMap.get(car);

            System.out.println("Registration Number: " + regNo);
            System.out.println("Keeper Details: " + keeper);
            System.out.println("--------------------");
        }
    }
}
