import java.io.Serializable;

/**
 * @author Sami Ullah
 * @version 1.0
 */

/**
 * Represents information about the registered keeper of a car, including forename, surname, and address.
 *
 * 
 */
public class Keeper  implements Serializable {
    private String forename;
    private String surname;
    private Address address;

    /**
     * Constructs a Keeper object with the specified forename, surname, and address.
     *
     * @param forename The forename of the keeper.
     * @param surname  The surname of the keeper.
     * @param address  The address of the keeper.
     */
    public Keeper(String forename, String surname, Address address) {
        this.forename = forename;
        this.surname = surname;
        this.address = address;
    }

    /**
     * Gets the forename of the keeper.
     *
     * @return The forename of the keeper.
     */
    public String getForename() {
        return forename;
    }

    /**
     * Gets the surname of the keeper.
     *
     * @return The surname of the keeper.
     */
    public String getSurname() {
        return surname;
    }

    /**
     * Gets the address of the keeper.
     *
     * @return The address of the keeper.
     */
    public Address getAddress() {
        return address;
    }

    /**
     * Sets the address of the keeper.
     *
     * @param address The new address of the keeper.
     */
    public void setAddress(Address address) {
        this.address = address;
    }

    /**
     * Returns a string representation of the keeper, including forename, surname, and address.
     *
     * @return A string representation of the keeper.
     */
    @Override
    public String toString() {
        return "Keeper{" +
                "forename='" + forename + '\'' +
                ", surname='" + surname + '\'' +
                ", address=" + address +
                '}';
    }
}
