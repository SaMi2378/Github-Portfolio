import java.util.Map;

/**
 * A test class to verify that reminder letters and warning letters can be sent to the appropriate keepers on any given month.
 * Implements first-class grade requirements including JavaDoc comments.
 *
 * @author Sami Ullah
 * @version 1.0
 */
public class Test004 {
    /**
     * Main method to execute the test.
     *
     * @param args The command-line arguments (not used).
     */
    public static void main(String[] args) {
        // Creating DVLA object
        DVLA dvla = new DVLA();

        // Creating Car objects
        Car car1 = new Car("Toyota", "Camry", "Blue", Month.JANUARY);
        Car car2 = new Car("Honda", "Civic", "Silver", Month.FEBRUARY);
        Car car3 = new Car("Ford", "Focus", "Red", Month.MARCH);

        // Creating Keeper objects
        Keeper keeper1 = new Keeper("John", "Doe", new Address("123 Main St", "City1", "12345"));
        Keeper keeper2 = new Keeper("Jane", "Smith", new Address("456 Oak St", "City2", "67890"));
        Keeper keeper3 = new Keeper("Bob", "Johnson", new Address("789 Pine St", "City3", "54321"));

        // Creating RegNo objects
        RegNo regNo1 = new RegNo("ABC123");
        RegNo regNo2 = new RegNo("XYZ789");
        RegNo regNo3 = new RegNo("DEF456");

        // Adding information for 3 cars to the DVLA HashMap
        dvla.addCarInfo(regNo1, car1, keeper1);
        dvla.addCarInfo(regNo2, car2, keeper2);
        dvla.addCarInfo(regNo3, car3, keeper3);

        // Testing reminder letters for a specific month
        Month reminderMonth = Month.MARCH;
        Map<RegNo, Keeper> reminderLetters = dvla.getReminderLetters(reminderMonth);
        System.out.println("Reminder Letters for " + reminderMonth + ":");
        reminderLetters.forEach((regNo, keeper) -> {
            System.out.println("Registration Number: " + regNo);
            System.out.println("Keeper Details: " + keeper);
            System.out.println("--------------------");
        });

        // Testing warning letters for a specific month
        Month warningMonth = Month.FEBRUARY;
        Map<RegNo, Keeper> warningLetters = dvla.getWarningLetters(warningMonth);
        System.out.println("Warning Letters for " + warningMonth + ":");
        warningLetters.forEach((regNo, keeper) -> {
            System.out.println("Registration Number: " + regNo);
            System.out.println("Keeper Details: " + keeper);
            System.out.println("--------------------");
        });
    }
}
