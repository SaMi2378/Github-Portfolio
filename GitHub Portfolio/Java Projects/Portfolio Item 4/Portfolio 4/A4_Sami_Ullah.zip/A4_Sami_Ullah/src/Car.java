
/**
 * @author Sami Ullah
 * @version 1.0
 */

/**
 * Represents information about a car, including make, model, and colour.
 */
public class Car {
    private final String make;
    private final String model;
    private String colour;
    private Month taxExpiresEndMonth;  // New field
    
    /**
     * Constructs a Car object with the specified make, model and colour.
     *
     * @param make   The make of the car.
     * @param model  The model of the car.
     * @param colour The colour of the car.
     */
    public Car(String make, String model, String colour) {
        this.make = make;
        this.model = model;
        this.colour = colour;
        
        
    }
    
    /**
     * Constructs a Car object with the specified make, model, colour and tax expiration month
     *
     * @param make   The make of the car.
     * @param model  The model of the car.
     * @param colour The colour of the car.
     * @param taxExpiresEndMonth 
     * @param taxExpiresEndMonth The month when tax expires.
     */
    public Car(String make, String model, String colour, Month taxExpiresEndMonth) {
        this.make = make;
        this.model = model;
        this.colour = colour;
        this.taxExpiresEndMonth = taxExpiresEndMonth;
        
    }

    /**
     * Gets the make of the car.
     *
     * @return The make of the car.
     */
    public String getMake() {
        return make;
    }

    /**
     * Gets the model of the car.
     *
     * @return The model of the car.
     */
    public String getModel() {
        return model;
    }

    /**
     * Gets the colour of the car.
     *
     * @return The colour of the car.
     */
    public String getColour() {
        return colour;
    }

    /**
     * Sets the colour of the car.
     *
     * @param colour The new colour of the car.
     */
    public void setColour(String colour) {
        this.colour = colour;
    }
    
    /**
     * Gets the tax expiry month of the car.
     *
     * @return The tax expiry month of the car.
     */
    public Month getTaxExpiresEndMonth() {
        return taxExpiresEndMonth;
    }	
    
    /**
     * Sets the tax expiry month of the car.
     *
     * @param taxExpiresEndMonth The new tax expiry month of the car.
     */
    public void setTaxExpiresEndMonth(Month taxExpiresEndMonth) {
        this.taxExpiresEndMonth = taxExpiresEndMonth;
    }

    /**
     * Returns a string representation of the Car object.
     *
     * @return A string representation of the Car object.
     */
    @Override
    public String toString() {
        return "Car{" +
                "make='" + make + '\'' +
                ", model='" + model + '\'' +
                ", colour='" + colour + '\'' +
                ", taxExpiresEndMonth=" + taxExpiresEndMonth +
                '}';
    }
}
