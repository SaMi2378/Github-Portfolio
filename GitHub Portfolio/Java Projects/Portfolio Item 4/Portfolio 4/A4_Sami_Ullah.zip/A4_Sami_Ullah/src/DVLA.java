import java.io.Serializable;
import java.util.HashMap;
import java.util.Map;

/**
 * Represents the DVLA (Driver and Vehicle Licensing Agency) that holds information about cars,
 * registration numbers, and keepers using HashMap data structures.
 * Implements Serializable for serialization support.
 */
public class DVLA implements Serializable {
    private Map<RegNo, Car> registrationNumberMap;
    private Map<Car, Keeper> carToKeeperMap;

    /**
     * Constructs a DVLA object with empty HashMaps for registration numbers and car-to-keeper mapping.
     */
    public DVLA() {
        this.registrationNumberMap = new HashMap<>();
        this.carToKeeperMap = new HashMap<>();
    }

    /**
     * Adds car, registration number, and keeper information to the DVLA HashMaps.
     *
     * @param regNo   The registration number.
     * @param car     The car information.
     * @param keeper  The keeper information.
     */
    public void addCarInfo(RegNo regNo, Car car, Keeper keeper) {
        registrationNumberMap.put(regNo, car);
        carToKeeperMap.put(car, keeper);
    }
    
    /**
     * Gets the registration number map.
     *
     * @return The registration number map.
     */
    public Map<RegNo, Car> getRegistrationNumberMap() {
        return registrationNumberMap;
    }

    /**
     * Gets the car to keeper map.
     *
     * @return The car to keeper map.
     */
    public Map<Car, Keeper> getCarToKeeperMap() {
        return carToKeeperMap;
    }
    
    
    /**
     * Displays all registration numbers and car details stored in the DVLA.
     */
    public void showAllCars() {
        System.out.println("All Cars in DVLA:");
        for (Map.Entry<RegNo, Car> entry : registrationNumberMap.entrySet()) {
            System.out.println("Registration Number: " + entry.getKey());
            System.out.println("Car Details: " + entry.getValue());
            System.out.println("--------------------");
        }
    }
    
    /**
     * Returns a data structure containing registration numbers, names, and addresses
     * of keepers whose car tax expires at the end of the specified month.
     *
     * @param expiryMonth The month for which reminder letters are needed.
     * @return A data structure with keeper details for reminder letters.
     */
    public Map<RegNo, Keeper> getReminderLetters(Month expiryMonth) {
        Map<RegNo, Keeper> reminderLetters = new HashMap<>();
        for (Map.Entry<RegNo, Car> entry : registrationNumberMap.entrySet()) {
            RegNo regNo = entry.getKey();
            Car car = entry.getValue();
            Keeper keeper = carToKeeperMap.get(car);

            if (car.getTaxExpiresEndMonth() == expiryMonth) {
                reminderLetters.put(regNo, keeper);
            }
        }
        return reminderLetters;
    }

    /**
     * Returns a data structure containing registration numbers, names, and addresses
     * of keepers whose car tax has already expired for the specified month.
     *
     * @param expiredMonth The month for which warning letters are needed.
     * @return A data structure with keeper details for warning letters.
     */
    public Map<RegNo, Keeper> getWarningLetters(Month expiredMonth) {
        Map<RegNo, Keeper> warningLetters = new HashMap<>();
        for (Map.Entry<RegNo, Car> entry : registrationNumberMap.entrySet()) {
            RegNo regNo = entry.getKey();
            Car car = entry.getValue();
            Keeper keeper = carToKeeperMap.get(car);

            if (car.getTaxExpiresEndMonth().ordinal() < expiredMonth.ordinal()) {
                warningLetters.put(regNo, keeper);
            }
        }
        return warningLetters;
    }
}
