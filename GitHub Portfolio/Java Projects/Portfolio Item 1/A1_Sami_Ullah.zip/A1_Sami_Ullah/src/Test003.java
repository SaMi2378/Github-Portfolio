import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;

/**
 * The Test003 class demonstrates natural ordering and stores appointments in ArrayList and arrays.
 *
 * @author Sami Ullah
 * @version 1.0
 */
public class Test003 {
    public static void main(String[] args) {

        // Create ArrayList of Appointment objects
        ArrayList<Appointment> appointmentList = new ArrayList<Appointment>();

        // Create appointments (same as before)

        // Add appointments to the list
        appointmentList.add(new Appointment("Josh Anderson", "Presentation 1", new Date(15, 10, 2023), new Time(8, 30), new MeetingRoom("B2-03")));
        appointmentList.add(new Appointment("John Smith", "Demo 1", new Date(19, 10, 2023), new Time(10, 15), new MeetingRoom("A1-01")));
        appointmentList.add(new Appointment("Usman Khan", "Demonstration 3", new Date(3, 10, 2023), new Time(13, 45), new MeetingRoom("C1-10")));
        appointmentList.add(new Appointment("Nick Ross", "Num 1", new Date(23, 10, 2023), new Time(12, 45), new MeetingRoom("D3-05")));
        appointmentList.add(new Appointment("James Red", "Meeting 1", new Date(20, 10, 2023), new Time(10, 45), new MeetingRoom("E3-08")));
        appointmentList.add(new Appointment("Romeo Julliet", "Demo 2", new Date(1, 9, 2023), new Time(13, 15), new MeetingRoom("D1-05")));
        appointmentList.add(new Appointment("Khan Ghazi", "Demo 3", new Date(20, 8, 2023), new Time(15, 10), new MeetingRoom("C2-10")));
        appointmentList.add(new Appointment("Marc Clarke", "Meeting 2", new Date(20, 11, 2023), new Time(11, 55), new MeetingRoom("E3-13")));
        appointmentList.add(new Appointment("Nick Jonas", "Discusion", new Date(3, 10, 2023), new Time(19, 30), new MeetingRoom("A1-08")));
        appointmentList.add(new Appointment("Naveed Sabir", "Meeting 3", new Date(7, 10, 2023), new Time(9, 45), new MeetingRoom("B1-08")));

        // Create an array of Appointment objects (same objects, in the same original order as ArrayList)
        Appointment[] appointmentArray = appointmentList.toArray(new Appointment[appointmentList.size()]);
        
        // Display appointments in chronological order from ArrayList (using for-each loop) before sorting
        System.out.println("####### LIST OF ALL APPOINTMENTS ##########");
        System.out.println("Appointments (ArrayList) Before Sorting:");
        int count=0;
        for (Appointment appointment : appointmentList) {
        	System.out.println("Appointment Number: " +count);
        	System.out.println(appointment);
        	count+=1;
        	System.out.println();
        }

        /**
         * Sort the ArrayList for natural ordering (based on the compareTo method) 
         */
        
        
        Collections.sort(appointmentList);
        
        /**
         * Display appointments in sorted order (ArrayList)
         */
        
        System.out.println("####### LIST OF ALL APPOINTMENTS AFTER SORTING #######");
        int count2=0;
        System.out.println("\nAppointments (ArrayList) Sorted chonologically:");
        for (Appointment appointment : appointmentList) {
        	System.out.println("Appointment Number: " +count2);
        	System.out.println(appointment);
        	count2+=1;
        	System.out.println();
        }

        
        
        

        System.out.println("####### LIST OF ALL APPOINTMENTS #######");
        // Display appointments in chronological order from the array
        int count3=0;
        System.out.println("\nAppointments (Array) in Chronological Order:");
        for (Appointment appointment : appointmentArray) {
        	System.out.println("Appointment Number: " +count3);
            System.out.println(appointment);
            count3+=1;
        	System.out.println();
        }

        // Sort the array for natural ordering (based on the compareTo method)
        Arrays.sort(appointmentArray);
        System.out.println("####### LIST OF ALL APPOINTMENTS AFTER SORTING #######");
        int count4=0;
        // Display appointments in chronological order from the array after sorting
        System.out.println("\nAppointments (Array) in Chronological Order (after sorting):");
        for (Appointment appointment : appointmentArray) {
        	System.out.println("Appointment Number: " +count4);
            System.out.println(appointment);
            count4+=1;
        	System.out.println();
        }

        
        
        /**
         * SEARCH appointment. The following code is to perform the binary search to get the search appointment.
         */
        
        System.out.println();
        System.out.println("####### SEARCHING AN APPOINTMENT ##########");
        
        
        // Create an unsorted searchAppointment
        Appointment searchAppointment = new Appointment("Khan Ghazi", "Demo 3", new Date(20, 8, 2023), new Time(15, 10), new MeetingRoom("C2-10"));
        
        // Clone searchAppointment
        Appointment searchAppointmentClone = (Appointment) searchAppointment.clone();
        
        // Search for the original searchAppointment in ArrayList
        int searchResult = Collections.binarySearch(appointmentList, searchAppointment);
        if (searchResult >= 0) {
            System.out.println("\nTarget Appointment found in ArrayList at index " + searchResult);
            System.out.println(appointmentList.get(searchResult));
        } else {
            System.out.println("\nTarget Appointment not found in ArrayList.");
        }

        // Search for the cloned searchAppointment in ArrayList
        searchResult = Collections.binarySearch(appointmentList, searchAppointmentClone);
        if (searchResult >= 0) {
            System.out.println("\nCloned Target Appointment found in ArrayList at index " + searchResult);
            System.out.println(appointmentList.get(searchResult));
        } else {
            System.out.println("\nCloned Target Appointment not found in ArrayList.");
        }

        // Search for the original searchAppointment in the array
        searchResult = Arrays.binarySearch(appointmentArray, searchAppointment);
        if (searchResult >= 0) {
            System.out.println("\nTarget Appointment found in Array at index " + searchResult);
            System.out.println(appointmentArray[searchResult]);
        } else {
            System.out.println("\nTarget Appointment not found in Array.");
        }

        // Search for the cloned searchAppointment in the array
        searchResult = Arrays.binarySearch(appointmentArray, searchAppointmentClone);
        if (searchResult >= 0) {
            System.out.println("\nCloned Target Appointment found in Array at index " + searchResult);
            System.out.println(appointmentArray[searchResult]);
        } else {
            System.out.println("\nCloned Target Appointment not found in Array.");
        }
        
        System.out.println("###########################################");
    }
}
