import java.util.Comparator;

/**
 * The Appointment class represents an appointment with a name, purpose, date, time, and meeting room.
 *
 * @author Sami Ullah
 * @version 1.0
 */
public class Appointment implements Cloneable, Comparable<Appointment>, Comparator<Appointment>{
    private String name;         // who to meet
    private String purpose;      // purpose of appointment
    private Date date;           // date of appointment
    private Time time;           // time of appointment
    private MeetingRoom room;    // where to meet

    /**
     * Default constructor that initializes the appointment with default values.
     */
    public Appointment() {
        this.name = "John Doe";
        this.purpose = "Meeting";
        this.date = new Date();
        this.time = new Time();
        this.room = new MeetingRoom();
    }

    /**
     * Parameter constructor that sets the attributes based on the provided values.
     *
     * @param name     the name of the person to meet
     * @param purpose  the purpose of the appointment
     * @param date     the date of the appointment
     * @param time     the time of the appointment
     * @param room     the meeting room for the appointment
     */
    public Appointment(String name, String purpose, Date date, Time time, MeetingRoom room) {
        this.name = name;
        this.purpose = purpose;
        this.date = date;
        this.time = time;
        this.room = room;
    }

    /**
     * Copy constructor that performs shallow copying of the appointment.
     *
     * @param other the appointment to copy
     */
    public Appointment(Appointment other) {
        this.name = other.name;
        this.purpose = other.purpose;
        this.date = (other.date);
        this.time = (other.time);
        this.room = (other.room);
    }

    /**
     * Gets the name of the person to meet.
     *
     * @return the name of the person
     */
    public String getName() {
        return name;
    }

    /**
     * Sets the name of the person to meet.
     *
     * @param name the name of the person to set
     */
    public void setName(String name) {
        this.name = name;
    }

    /**
     * Gets the purpose of the appointment.
     *
     * @return the purpose of the appointment
     */
    public String getPurpose() {
        return purpose;
    }

    /**
     * Sets the purpose of the appointment.
     *
     * @param purpose the purpose of the appointment to set
     */
    public void setPurpose(String purpose) {
        this.purpose = purpose;
    }

    /**
     * Gets the date of the appointment.
     *
     * @return the date of the appointment
     */
    public Date getDate() {
        return date;
    }

    /**
     * Sets the date of the appointment.
     *
     * @param date the date of the appointment to set
     */
    public void setDate(Date date) {
        this.date = date;
    }

    /**
     * Gets the time of the appointment.
     *
     * @return the time of the appointment
     */
    public Time getTime() {
        return time;
    }

    /**
     * Sets the time of the appointment.
     *
     * @param time the time of the appointment to set
     */
    public void setTime(Time time) {
        this.time = time;
    }

    /**
     * Gets the meeting room for the appointment.
     *
     * @return the meeting room for the appointment
     */
    public MeetingRoom getRoom() {
        return room;
    }

    /**
     * Sets the meeting room for the appointment.
     *
     * @param room the meeting room for the appointment to set
     */
    public void setRoom(MeetingRoom room) {
        this.room = room;
    }
    
    
    /**
     * Creates a deep copy of the appointment object.
     *
     * @return a deep copy of the appointment
     */
    @Override
    public Object clone() {
        try {
            Appointment copy = (Appointment) super.clone();
            copy.date = (Date) date.clone();
            copy.time = (Time) time.clone();
            copy.room = (MeetingRoom) room.clone();
            return copy;
        } catch (CloneNotSupportedException e) {
            throw new InternalError(e);
        }
    }
    
    /**
     * Compares this appointment to another appointment for natural ordering based on date and time.
     *
     * @param other the other appointment to compare to
     * @return a negative integer, zero, or a positive integer as this appointment is earlier, the same, or later than the other
     */
//    @Override
//    public int compareTo(Appointment other) {
//        long thisDateTime = this.dateToLong() * 10000L + this.timeToLong();
//        long otherDateTime = other.dateToLong() * 10000L + other.timeToLong();
//        return Long.compare(thisDateTime, otherDateTime);
//    }

    @Override
    public int compareTo(Appointment other) {
        int dateComparison = this.date.compareTo(other.date);
        if (dateComparison != 0) {
            return dateComparison;
        } else {
            int timeComparison = this.time.compareTo(other.time);
            if (timeComparison != 0) {
                return timeComparison;
            } else {
                return this.room.compareTo(other.room); //Added as a backup option
            }
        }
    }
    
    
    
    
    // Helper methods to convert date and time to long values
//    private long dateToLong() {
//        return this.date.getYear() * 10000L + this.date.getMonth() * 100L + this.date.getDay();
//    }
//
//    private long timeToLong() {
//        return this.time.getHour() * 100L + this.time.getMinute();
//    }

    
    
    @Override
    public int compare(Appointment appointment1, Appointment appointment2) {
        String room1Floor = appointment1.getRoom().getRoom().substring(1, 2);
        String room2Floor = appointment2.getRoom().getRoom().substring(1, 2);

        int floor1 = Integer.parseInt(room1Floor);
        int floor2 = Integer.parseInt(room2Floor);

        return Integer.compare(floor1, floor2);
    }
    

    /**
     * Returns a string representation of the appointment's attributes.
     *
     * @return a formatted string with appointment details
     */
    @Override
    public String toString() {
        return "Appointment Details:\n" +
                "Name: " + name + "\n" +
                "Purpose: " + purpose + "\n" +
                "Date: " + date + "\n" +
                "Time: " + time + "\n" +
                "Room: " + room;
    }

	

	
	
}
