/**
 * The Test001 class demonstrates shallow copying of Appointment objects.
 *
 * @author Sami Ullah
 * @version 1.0
 */
public class Test001 {
    public static void main(String[] args) {
        // Create an initial appointment
        Date date = new Date(18, 10, 2023);
        Time time = new Time(14, 30);
        MeetingRoom room = new MeetingRoom("B2-15");
        Appointment originalAppointment = new Appointment("Sami Ullah", "Review Meeting", date, time, room);

        // Perform shallow copying to create a new appointment
        Appointment copiedAppointment = new Appointment(originalAppointment);

        // Display the original and copied appointments
        System.out.println("Original Appointment:\n" + originalAppointment);
        
        
        // Print memory addresses (hashcodes)      
        
        System.out.println("Memory Address of Original Appointment: " + originalAppointment.hashCode());
        
        System.out.println("\nCopied Appointment:\n" + copiedAppointment);        
        
        // Print memory addresses (hashcodes)      
        System.out.println("Memory Address of Copied Appointment: " + copiedAppointment.hashCode());
        
        /**
         * Verification of the Shallow Copy
         * 
         * If the shallow copy is happening the memory address of Date, Time and Room
         * should be the same in both original appointment and copied appointment.
         *
         */
        
        System.out.println();
        System.out.println("######### Verifying #########");
       
        System.out.println("Memory Address of Date from Original Appointment: "+originalAppointment.getDate().hashCode());
        System.out.println("Memory Address of Time from Original Appointment: "+originalAppointment.getTime().hashCode());
        System.out.println("Memory Address of MeetingRoom from Original Appointment: "+originalAppointment.getRoom().hashCode());
    
        System.out.println();
        System.out.println("Memory Address of Date from Copied Appointment: "+copiedAppointment.getDate().hashCode());
        System.out.println("Memory Address of Time from Copied Appointment: "+copiedAppointment.getTime().hashCode());
        System.out.println("Memory Address of MeetingRoom from copied Appointment: "+copiedAppointment.getRoom().hashCode());
        System.out.println("#############################");      
        
    }
}
