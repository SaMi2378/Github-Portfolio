import java.util.Comparator;

/**
 * The SortByRoomFloor class is a comparator for sorting Appointment objects by the floor of the meeting room.
 * If rooms are on the same floor, they are ordered naturally (alphabetically).
 *
 * @author Sami Ullah
 * @version 1.0
 */
public class SortByRoomFloor implements Comparator<Appointment> {

    /**
     * Compares two appointments for sorting based on room floor.
     *
     * @param appointment1 the first appointment
     * @param appointment2 the second appointment
     * @return a negative integer, zero, or a positive integer as appointment1 is lower, equal, or higher than appointment2
     */
    @Override
    public int compare(Appointment appointment1, Appointment appointment2) {
        String room1Floor = appointment1.getRoom().getRoom().substring(1, 2);
        String room2Floor = appointment2.getRoom().getRoom().substring(1, 2);

        int floor1 = Integer.parseInt(room1Floor);
        int floor2 = Integer.parseInt(room2Floor);

        if (floor1 == floor2) {
            // If rooms are on the same floor, order them naturally (alphabetically)
            return appointment1.getRoom().compareTo(appointment2.getRoom());
        } else {
            // Sort by floor (lowest first)
            return Integer.compare(floor1, floor2);
        }
    }
}
