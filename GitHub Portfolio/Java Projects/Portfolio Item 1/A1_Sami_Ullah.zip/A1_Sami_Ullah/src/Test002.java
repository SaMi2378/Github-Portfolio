/**
 * The Test002 class demonstrates deep copying of Appointment objects.
 *
 * @author Sami Ullah
 * @version 1.0
 * 
 */
public class Test002 {
    public static void main(String[] args) {
        // Create an initial appointment
        Date date = new Date(29, 9, 2023);
        Time time = new Time(14, 30);
        MeetingRoom room = new MeetingRoom("B2-15");
        Appointment originalAppointment = new Appointment("Sami Ullah", "Review Meeting", date, time, room);

        // Perform deep copying to create a new appointment
        Appointment copiedAppointment = (Appointment) originalAppointment.clone();

        // Modify the copied appointment
//        copiedAppointment.setName(" Sam Naveed");
//        copiedAppointment.getDate().setDay(29);
//        copiedAppointment.getTime().setHour(15);
//        copiedAppointment.getRoom().setRoom("C3-01");

        // Display the original and copied appointments
        System.out.println("Original Appointment:\n" + originalAppointment);
        
        // Print memory addresses (hashcodes)      
        
        System.out.println("Memory Address of Original Appointment: " + originalAppointment.hashCode());
        
        
        System.out.println("\nCopied Appointment:\n" + copiedAppointment);
    
        // Print memory addresses (hashcodes)      
        System.out.println("Memory Address of Copied Appointment: " + copiedAppointment.hashCode());
        
    
    
        /**
         * Testing and verifying the deep copy has been archived. 
         * 
         */
        System.out.println();
        System.out.println("##########   Verifying Deepcopy   ###########");
        Date date2 = new Date(21, 11, 2023);
        Time time2 = new Time(14, 30);
        MeetingRoom room2 = new MeetingRoom("B1-08");
        Appointment originalAppointment2 = new Appointment("John Henson", "Review Meeting", date2, time2, room2);

        // Perform deep copying to create a new appointment
        Appointment copiedAppointment2 = (Appointment) originalAppointment2.clone();

        // Modify the copied appointment
        copiedAppointment2.setName("Hafsa Khatoon");
        copiedAppointment2.getTime().setHour(15);
        copiedAppointment2.getRoom().setRoom("C2-13");

        // Display the original and copied appointments
        System.out.println("Original Appointment2:\n" + originalAppointment2);
        System.out.println("\nCopied Appointment2 (with modifications):\n" + copiedAppointment2);
        System.out.println();
        System.out.println("Memory Address of Date from Original Appointment: "+originalAppointment2.getDate().hashCode());
        System.out.println("Memory Address of Time from Original Appointment: "+originalAppointment2.getTime().hashCode());
        System.out.println("Memory Address of MeetingRoom from Original Appointment: "+originalAppointment2.getRoom().hashCode());
    
        System.out.println();
        System.out.println("Memory Address of Date from Copied Appointment: "+copiedAppointment2.getDate().hashCode());
        System.out.println("Memory Address of Time from Copied Appointment: "+copiedAppointment2.getTime().hashCode());
        System.out.println("Memory Address of MeetingRoom from copied Appointment: "+copiedAppointment2.getRoom().hashCode());
        
        System.out.println();
        System.out.println("###### Verification Has Been Completed ######");
        
    
    }
    
}
