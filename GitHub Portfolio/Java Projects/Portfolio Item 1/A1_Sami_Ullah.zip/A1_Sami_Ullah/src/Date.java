/**
 * The Date class represents a date with day, month, and year.
 *
 * @author Sami Ullah
 * @version 1.0
 */
public class Date implements Cloneable{
    private int day;    // day of the month (1-31)
    private int month;  // month of the year (1-12)
    private int year;   // year (e.g., 2008)

    /**
     * Default constructor that initializes the date to January 1, 2000.
     */
    public Date() {
        this.day = 1;
        this.month = 1;
        this.year = 2000;
    }

    /**
     * Parameter constructor that sets the day, month, and year based on the provided values.
     *
     * @param day   the day of the month (1-31)
     * @param month the month of the year (1-12)
     * @param year  the year value (e.g., 2008)
     */
    public Date(int day, int month, int year) {
        this.day = day;
        this.month = month;
        this.year = year;
    }

    /**
     * Copy constructor that performs shallow copying of the date.
     *
     * @param other the date to copy
     */
    public Date(Date other) {
        this.day = other.day;
        this.month = other.month;
        this.year = other.year;
    }

    /**
     * Gets the day of the month.
     *
     * @return the day of the month (1-31)
     */
    public int getDay() {
        return day;
    }

    /**
     * Sets the day of the month.
     *
     * @param day the day of the month to set (1-31)
     */
    public void setDay(int day) {
        this.day = day;
    }

    /**
     * Gets the month of the year.
     *
     * @return the month of the year (1-12)
     */
    public int getMonth() {
        return month;
    }

    /**
     * Sets the month of the year.
     *
     * @param month the month of the year to set (1-12)
     */
    public void setMonth(int month) {
        this.month = month;
    }

    /**
     * Gets the year.
     *
     * @return the year value (e.g., 2008)
     */
    public int getYear() {
        return year;
    }

    /**
     * Sets the year.
     *
     * @param year the year value to set (e.g., 2008)
     */
    public void setYear(int year) {
        this.year = year;
    }
    
    /**
     * Creates a deep copy of the date object.
     *
     * @return a deep copy of the date
     */
    @Override
    public Object clone() {
        try {
            return super.clone();
        } catch (CloneNotSupportedException e) {
            throw new InternalError(e);
        }
    }
    
    
    public int compareTo(Date other) {
        long thisValue = year * 10000L + month * 100L + day;
        long otherValue = other.year * 10000L + other.month * 100L + other.day;
        return Long.compare(thisValue, otherValue);
    }
    
    

    /**
     * Returns a formatted string representation of the date.
     *
     * @return a string in the "dd-MM-yyyy" format
     */
    @Override
    public String toString() {
        return String.format("%02d-%02d-%04d", day, month, year);
    }
}
