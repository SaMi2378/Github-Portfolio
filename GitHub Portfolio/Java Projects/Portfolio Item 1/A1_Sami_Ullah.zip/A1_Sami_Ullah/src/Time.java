/**
 * The Time class represents a time with hours and minutes.
 *
 * @author Sami Ullah
 * @version 1.0
 */
public class Time implements Cloneable{
    private int hour;    // hour in the day (0-23)
    private int minute;  // minute within the hour (0-59)

    /**
     * Default constructor that initializes the time to 00:00.
     */
    public Time() {
        this.hour = 0;
        this.minute = 0;
    }

    /**
     * Parameter constructor that sets the hour and minute based on the provided values.
     *
     * @param hour   the hour value (0-23)
     * @param minute the minute value (0-59)
     */
    public Time(int hour, int minute) {
        this.hour = hour;
        this.minute = minute;
    }

    /**
     * Copy constructor that performs shallow copying of the time.
     *
     * @param other the time to copy
     */
    public Time(Time other) {
        this.hour = other.hour;
        this.minute = other.minute;
    }

    /**
     * Gets the hour value.
     *
     * @return the hour value (0-23)
     */
    public int getHour() {
        return hour;
    }

    /**
     * Sets the hour value.
     *
     * @param hour the hour value to set (0-23)
     */
    public void setHour(int hour) {
        this.hour = hour;
    }

    /**
     * Gets the minute value.
     *
     * @return the minute value (0-59)
     */
    public int getMinute() {
        return minute;
    }

    /**
     * Sets the minute value.
     *
     * @param minute the minute value to set (0-59)
     */
    public void setMinute(int minute) {
        this.minute = minute;
    }
    
    /**
     * Creates a deep copy of the time object.
     *
     * @return a deep copy of the time
     */
    @Override
    public Object clone() {
        try {
            return super.clone();
        } catch (CloneNotSupportedException e) {
            throw new InternalError(e);
        }
    }
    
    
    
    public int compareTo(Time other) {
        // Construct a Long value representing the time (HHMM)
        long thisValue = hour * 100L + minute;
        long otherValue = other.hour * 100L + other.minute;
        return Long.compare(thisValue, otherValue);
    }
    

    /**
     * Returns a formatted string representation of the time.
     *
     * @return a string in the "HH:mm" format
     */
    @Override
    public String toString() {
        return String.format("%02d:%02d", hour, minute);
    }
}
