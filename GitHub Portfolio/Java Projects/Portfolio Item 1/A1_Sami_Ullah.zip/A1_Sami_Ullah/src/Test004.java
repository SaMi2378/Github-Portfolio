import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;

/**
 * The Test004 class re-sorts both array and ArrayList of Appointment objects by room floor and demonstrates the code.
 *
 * @author Sami Ullah
 * @version 1.0
 */
public class Test004 {
    public static void main(String[] args) {
        // Create ArrayList of Appointment objects
        ArrayList<Appointment> appointmentList = new ArrayList<Appointment>();

        // Create appointments (as shown in Test003)
        
        appointmentList.add(new Appointment("Josh Anderson", "Presentation 1", new Date(15, 10, 2023), new Time(8, 30), new MeetingRoom("B2-03")));
        appointmentList.add(new Appointment("John Smith", "Demo 1", new Date(19, 10, 2023), new Time(10, 15), new MeetingRoom("A1-01")));
        appointmentList.add(new Appointment("Usman Khan", "Demonstration 3", new Date(3, 10, 2023), new Time(13, 45), new MeetingRoom("C1-10")));
        appointmentList.add(new Appointment("Nick Ross", "Num 1", new Date(23, 10, 2023), new Time(12, 45), new MeetingRoom("D3-05")));
        appointmentList.add(new Appointment("James Red", "Meeting 1", new Date(20, 10, 2023), new Time(10, 45), new MeetingRoom("E3-08")));
        appointmentList.add(new Appointment("Romeo Julliet", "Demo 2", new Date(1, 9, 2023), new Time(13, 15), new MeetingRoom("D1-05")));
        appointmentList.add(new Appointment("Khan Ghazi", "Demo 3", new Date(20, 8, 2023), new Time(15, 10), new MeetingRoom("C2-10")));
        appointmentList.add(new Appointment("Marc Clarke", "Meeting 2", new Date(20, 11, 2023), new Time(11, 55), new MeetingRoom("E3-13")));
        appointmentList.add(new Appointment("Nick Jonas", "Discusion", new Date(3, 10, 2023), new Time(19, 30), new MeetingRoom("A1-08")));
        appointmentList.add(new Appointment("Naveed Sabir", "Meeting 3", new Date(7, 10, 2023), new Time(9, 45), new MeetingRoom("B1-08")));
        
        // Display appointments in chronological order (ArrayList)
        System.out.println("Appointments (ArrayList) in Chronological Order:");
        for (Appointment appointment : appointmentList) {
        	System.out.println(appointment);
        }

        // Create an array of Appointment objects (same objects, in the same original order as ArrayList)
        Appointment[] appointmentArray = appointmentList.toArray(new Appointment[appointmentList.size()]);

        // Sort the ArrayList for natural ordering 
        Collections.sort(appointmentList);

        // Re-sort both array and ArrayList by room floor using SortByRoomFloor comparator
        Arrays.sort(appointmentArray, new SortByRoomFloor());
        Collections.sort(appointmentList, new SortByRoomFloor());
        
        
        // Create an unsorted searchAppointment
        Appointment searchAppointment = new Appointment("Khan Ghazi", "Demo 3", new Date(20, 8, 2023), new Time(15, 10), new MeetingRoom("C2-10"));

        // Clone searchAppointment by deep copy
        Appointment searchAppointmentClone = (Appointment) searchAppointment.clone();

        // Search for searchAppointment in both array and ArrayList
        int arrayIndex = Arrays.binarySearch(appointmentArray, searchAppointment, new SortByRoomFloor());
        int listIndex = Collections.binarySearch(appointmentList, searchAppointment, new SortByRoomFloor());

        // Search for searchAppointmentClone in both array and ArrayList
        int arrayCloneIndex = Arrays.binarySearch(appointmentArray, searchAppointmentClone, new SortByRoomFloor());
        int listCloneIndex = Collections.binarySearch(appointmentList, searchAppointmentClone, new SortByRoomFloor());

        


        // Display appointments in sorted order (ArrayList)
        System.out.println("\nAppointments (ArrayList) Sorted by Room Floor:");
        for (Appointment appointment : appointmentList) {
            System.out.println(appointment);
        }

        // Display appointments in sorted order (array)
        System.out.println("\nAppointments (Array) Sorted by Room Floor:");
        for (Appointment appointment : appointmentArray) {
            System.out.println(appointment);
        }
        
        // Check if searchAppointment was found in both array and ArrayList
        if (arrayIndex >= 0 && listIndex >= 0) {

            System.out.println("\nSearch Appointment found in Array at position: "+ arrayIndex);
            System.out.println("Found Search Appointment (Array): "+ "\n"  + appointmentArray[arrayIndex]);
            System.out.println("\nSearch Appointment found in ArrayList at position: "+ listIndex);
            System.out.println("Found Search Appointment (ArrayList): "+ "\n"  + appointmentList.get(listIndex));
        } else {
            System.out.println("\nSearch Appointment not found in both array and ArrayList.");
        }

        // Check if searchAppointmentClone was found in both array and ArrayList
        if (arrayCloneIndex >= 0 && listCloneIndex >= 0) {
          
            System.out.println("\nSearch Appointment Clone found in Array at position: "+ arrayCloneIndex);
            System.out.println("Found Search Appointment Clone (Array): " + "\n" + appointmentArray[arrayCloneIndex]);
            System.out.println("\nSearch Appointment Clone found in ArrayList at position: "+ listCloneIndex);
            System.out.println("Found Search Appointment Clone (ArrayList): " + "\n"  + appointmentList.get(listCloneIndex));
        } else {
            System.out.println("Search Appointment Clone not found in both array and ArrayList.");
        }
        
        
    }
}
