/**
 * The MeetingRoom class represents a meeting room with a room name.
 *
 * @author Sami Ullah
 * @version 1.0
 */
public class MeetingRoom implements Cloneable{
    private String room;  // room in String format (e.g., B1-05, C2-08, T4-34)

    /**
     * Default constructor that initializes the meeting room with a default name.
     */
    public MeetingRoom() {
        this.room = "A1-01";
    }

    /**
     * Parameter constructor that sets the room name based on the provided value.
     *
     * @param room the room name
     */
    public MeetingRoom(String room) {
        this.room = room;
    }

    /**
     * Copy constructor that performs shallow copying of the meeting room.
     *
     * @param other the meeting room to copy
     */
    public MeetingRoom(MeetingRoom other) {
        this.room = other.room;
    }

    /**
     * Gets the room name.
     *
     * @return the room name
     */
    public String getRoom() {
        return room;
    }

    /**
     * Sets the room name.
     *
     * @param room the room name to set
     */
    public void setRoom(String room) {
        this.room = room;
    }
    
    
    /**
     * Creates a deep copy of the meeting room object.
     *
     * @return a deep copy of the meeting room
     */
    @Override
    public Object clone() {
        try {
            return super.clone();
        } catch (CloneNotSupportedException e) {
            throw new InternalError(e);
        }
    }
    
   
    public int compareTo(MeetingRoom other) {
        return room.compareTo(other.room);
    }

    /**
     * Returns the room name as a string.
     *
     * @return the room name
     */
    @Override
    public String toString() {
        return room;
    }
}
