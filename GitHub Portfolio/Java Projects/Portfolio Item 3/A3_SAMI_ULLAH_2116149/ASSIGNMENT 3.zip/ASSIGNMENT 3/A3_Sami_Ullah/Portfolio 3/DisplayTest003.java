import javax.swing.*;
import javax.swing.tree.DefaultMutableTreeNode;
import javax.swing.tree.DefaultTreeModel;
import java.awt.*;

/**
 * The DisplayTest003 class creates a DefaultTreeModel and displays the employee hierarchy using a JTree.
 * It fulfills the requirements for the first-class grade.
 *
 * @author Sami Ullah
 */
public class DisplayTest003 {

    /**
     * The main method creates a DefaultTreeModel, associates it with a JTree, and displays the hierarchy.
     *
     * @param args The command-line arguments (not used in this application).
     */
    public static void main(String[] args) {
        // Create employees (same as in DisplayTest001)
    	Employee mohammedAli = new Employee("Mohammed", "Ali", "Senior Partner", 120000);
        Employee saraJohnson = new Employee("Sara", "Johnson", "Managing Partner", 89000);
        Employee sandraDee = new Employee("Sandra", "Dee", "Partner", 78500);
        Employee fredDibner = new Employee("Fred", "Dibner", "Finance Manager", 67900);
        Employee cleoPatra = new Employee("Cleo", "Patra", "Junior Partner", 45000);
        Employee irfanPatel = new Employee("Irfan", "Patel", "Junior Partner", 45000);
        Employee georgeBush = new Employee("George", "Bush", "Office Manager", 37000);
        Employee harryPotter = new Employee("Harry", "Potter", "Solicitor", 52500);
        Employee ronaldReagan = new Employee("Ronald", "Reagan", "Senior Clerk", 22000);
        Employee simonTemplar = new Employee("Simon", "Templar", "Finance Officer", 18000);
        Employee jacobHeart = new Employee("Jacob", "Heart", "Clerk", 16000);
        Employee barryDwyer = new Employee("Barry", "Dwyer", "Clerk", 16000);
        Employee maryFritz = new Employee("Mary", "Fritz", "Clerk", 16000);
        Employee gordonBrown = new Employee("Gordon", "Brown", "Finance Clerk", 16500);

        // Create tree nodes with employee objects (same as in DisplayTest001)
        DefaultMutableTreeNode root = new DefaultMutableTreeNode(mohammedAli);
        DefaultMutableTreeNode nodeSaraJohnson = new DefaultMutableTreeNode(saraJohnson);
        DefaultMutableTreeNode nodeSandraDee = new DefaultMutableTreeNode(sandraDee);
        DefaultMutableTreeNode nodeFredDibner = new DefaultMutableTreeNode(fredDibner);
        DefaultMutableTreeNode nodeCleoPatra = new DefaultMutableTreeNode(cleoPatra);
        DefaultMutableTreeNode nodeIrfanPatel = new DefaultMutableTreeNode(irfanPatel);
        DefaultMutableTreeNode nodeGeorgeBush = new DefaultMutableTreeNode(georgeBush);
        DefaultMutableTreeNode nodeHarryPotter = new DefaultMutableTreeNode(harryPotter);
        DefaultMutableTreeNode nodeRonaldReagan = new DefaultMutableTreeNode(ronaldReagan);
        DefaultMutableTreeNode nodeJacobHeart = new DefaultMutableTreeNode(jacobHeart);
        DefaultMutableTreeNode nodeBarryDwyer = new DefaultMutableTreeNode(barryDwyer);
        DefaultMutableTreeNode nodeMaryFritz = new DefaultMutableTreeNode(maryFritz);
        DefaultMutableTreeNode nodeSimonTemplar = new DefaultMutableTreeNode(simonTemplar);
        DefaultMutableTreeNode nodeGordonBrown = new DefaultMutableTreeNode(gordonBrown);

        // Build the hierarchy by adding child nodes to parent nodes (same as in DisplayTest001)
        root.add(nodeSaraJohnson);
        root.add(nodeSandraDee);
        root.add(nodeFredDibner);
        nodeSaraJohnson.add(nodeCleoPatra);
        nodeSaraJohnson.add(nodeIrfanPatel);
        nodeSaraJohnson.add(nodeGeorgeBush);
        nodeSandraDee.add(nodeHarryPotter);
        nodeSandraDee.add(nodeRonaldReagan);
        nodeGeorgeBush.add(nodeJacobHeart);
        nodeGeorgeBush.add(nodeBarryDwyer);
        nodeRonaldReagan.add(nodeMaryFritz);
        nodeFredDibner.add(nodeSimonTemplar);
        nodeSimonTemplar.add(nodeGordonBrown);

        // Create a DefaultTreeModel with the root node
        DefaultTreeModel treeModel = new DefaultTreeModel(root);

        // Create a JFrame and JTree to display the hierarchy
        JFrame frame = new JFrame("Employee Hierarchy");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        JTree tree = new JTree(treeModel);
        JScrollPane scrollPane = new JScrollPane(tree);
        frame.add(scrollPane, BorderLayout.CENTER);

        // Set frame properties
        frame.setSize(400, 300);
        frame.setLocationRelativeTo(null); // Center the frame
        frame.setVisible(true);
    }
}
