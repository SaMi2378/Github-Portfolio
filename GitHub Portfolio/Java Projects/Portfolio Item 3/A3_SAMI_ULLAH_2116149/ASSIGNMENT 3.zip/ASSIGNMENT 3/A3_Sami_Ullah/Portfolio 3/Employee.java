/**
 * @author SAMI ULLAH
 * Employee class represents an employee in the company.
 * Each employee has a forename, surname, title, and salary.
 */
public class Employee implements Cloneable {

    // Attributes
    private String forename;
    private String surname;
    private String title;
    private float salary;

    /**
     * Default constructor initializes attributes to sensible values.
     */
    public Employee() {
        forename = "Donald";
        surname = "Duck";
        title = "Sales rep";
        salary = 24575;
    }

    /**
     * Parameter constructor sets all attribute values based on the parameters.
     *
     * @param forename The forename of the employee.
     * @param surname  The surname of the employee.
     * @param title    The title of the employee.
     * @param salary   The salary of the employee.
     */
    public Employee(String forename, String surname, String title, float salary) {
        this.forename = forename;
        this.surname = surname;
        this.title = title;
        this.salary = salary;
    }

    // Getter and Setter methods for each attribute

    /**
     * Gets the forename of the employee.
     *
     * @return The forename of the employee.
     */
    public String getForename() {
        return forename;
    }

    /**
     * Sets the forename of the employee.
     *
     * @param forename The forename to set.
     */
    public void setForename(String forename) {
        this.forename = forename;
    }

    /**
     * Gets the surname of the employee.
     *
     * @return The surname of the employee.
     */
    public String getSurname() {
        return surname;
    }

    /**
     * Sets the surname of the employee.
     *
     * @param surname The surname to set.
     */
    public void setSurname(String surname) {
        this.surname = surname;
    }

    /**
     * Gets the title of the employee.
     *
     * @return The title of the employee.
     */
    public String getTitle() {
        return title;
    }

    /**
     * Sets the title of the employee.
     *
     * @param title The title to set.
     */
    public void setTitle(String title) {
        this.title = title;
    }

    /**
     * Gets the salary of the employee.
     *
     * @return The salary of the employee.
     */
    public float getSalary() {
        return salary;
    }

    /**
     * Sets the salary of the employee.
     *
     * @param salary The salary to set.
     */
    public void setSalary(float salary) {
        this.salary = salary;
    }

    /**
     * Returns a suitably formatted string of the attribute values.
     *
     * @return A formatted string representing the employee.
     */
    @Override
    public String toString() {
        return "Employee{" +
                "forename='" + forename + '\'' +
                ", surname='" + surname + '\'' +
                ", title='" + title + '\'' +
                ", salary=" + salary +
                '}';
    }

    /**
     * Creates and returns a copy of this object.
     *
     * @return A clone of this employee.
     * @throws CloneNotSupportedException If cloning is not supported.
     */
    @Override
    public Object clone() throws CloneNotSupportedException {
        return super.clone();
    }
}
