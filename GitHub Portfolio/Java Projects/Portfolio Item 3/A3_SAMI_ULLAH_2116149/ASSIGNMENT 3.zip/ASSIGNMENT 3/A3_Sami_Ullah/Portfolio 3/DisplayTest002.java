import javax.swing.tree.DefaultMutableTreeNode;

/**
 * The DisplayTest002 class demonstrates recursion to perform specific tasks on the employee hierarchy.
 *
 * @author Sami Ullah
 */
public class DisplayTest002 {
	// ANSI escape codes for console colors
    public static final String ANSI_RESET = "\u001B[0m";
    public static final String ANSI_BOLD = "\u001B[1m";
    public static final String ANSI_BLACK = "\u001B[30m";
    public static final String ANSI_RED = "\u001B[31m";
    public static final String ANSI_BLUE = "\u001B[34m";


    /**
     * The main method demonstrates tasks using recursion on the employee hierarchy.
     *
     * @param args The command-line arguments (not used in this application).
     */
    public static void main(String[] args) {
        // Create employees
    	Employee mohammedAli = new Employee("Mohammed", "Ali", "Senior Partner", 120000);
        Employee saraJohnson = new Employee("Sara", "Johnson", "Managing Partner", 89000);
        Employee sandraDee = new Employee("Sandra", "Dee", "Partner", 78500);
        Employee fredDibner = new Employee("Fred", "Dibner", "Finance Manager", 67900);
        Employee cleoPatra = new Employee("Cleo", "Patra", "Junior Partner", 45000);
        Employee irfanPatel = new Employee("Irfan", "Patel", "Junior Partner", 45000);
        Employee georgeBush = new Employee("George", "Bush", "Office Manager", 37000);
        Employee harryPotter = new Employee("Harry", "Potter", "Solicitor", 52500);
        Employee ronaldReagan = new Employee("Ronald", "Reagan", "Senior Clerk", 22000);
        Employee simonTemplar = new Employee("Simon", "Templar", "Finance Officer", 18000);
        Employee jacobHeart = new Employee("Jacob", "Heart", "Clerk", 16000);
        Employee barryDwyer = new Employee("Barry", "Dwyer", "Clerk", 16000);
        Employee maryFritz = new Employee("Mary", "Fritz", "Clerk", 16000);
        Employee gordonBrown = new Employee("Gordon", "Brown", "Finance Clerk", 16500);

        // Create tree nodes with employee objects
        DefaultMutableTreeNode root = new DefaultMutableTreeNode(mohammedAli);

        DefaultMutableTreeNode nodeSaraJohnson = new DefaultMutableTreeNode(saraJohnson);
        DefaultMutableTreeNode nodeSandraDee = new DefaultMutableTreeNode(sandraDee);
        DefaultMutableTreeNode nodeFredDibner = new DefaultMutableTreeNode(fredDibner);
        DefaultMutableTreeNode nodeCleoPatra = new DefaultMutableTreeNode(cleoPatra);
        DefaultMutableTreeNode nodeIrfanPatel = new DefaultMutableTreeNode(irfanPatel);

        DefaultMutableTreeNode nodeGeorgeBush = new DefaultMutableTreeNode(georgeBush);
        DefaultMutableTreeNode nodeHarryPotter = new DefaultMutableTreeNode(harryPotter);
        DefaultMutableTreeNode nodeRonaldReagan = new DefaultMutableTreeNode(ronaldReagan);

        DefaultMutableTreeNode nodeJacobHeart = new DefaultMutableTreeNode(jacobHeart);
        DefaultMutableTreeNode nodeBarryDwyer = new DefaultMutableTreeNode(barryDwyer);
        DefaultMutableTreeNode nodeMaryFritz = new DefaultMutableTreeNode(maryFritz);

        DefaultMutableTreeNode nodeSimonTemplar = new DefaultMutableTreeNode(simonTemplar);
        DefaultMutableTreeNode nodeGordonBrown = new DefaultMutableTreeNode(gordonBrown);

        // Build the hierarchy by adding child nodes to parent nodes
        root.add(nodeSaraJohnson);
        root.add(nodeSandraDee);
        root.add(nodeFredDibner);
        nodeSaraJohnson.add(nodeCleoPatra);
        nodeSaraJohnson.add(nodeIrfanPatel);
        nodeSaraJohnson.add(nodeGeorgeBush);
        nodeSandraDee.add(nodeHarryPotter);
        nodeSandraDee.add(nodeRonaldReagan);
        nodeGeorgeBush.add(nodeJacobHeart);
        nodeGeorgeBush.add(nodeBarryDwyer);
        nodeRonaldReagan.add(nodeMaryFritz);
        nodeFredDibner.add(nodeSimonTemplar);
        nodeSimonTemplar.add(nodeGordonBrown);

        // Task (a): Display all people earning over £50000
        System.out.println(ANSI_BOLD + ANSI_RED +"--> People earning over £50000: <--"+ ANSI_BOLD + ANSI_BLACK );
        displayPeopleWithSalaryOver(root, 50000);

        System.out.println(ANSI_RESET +"\n---------------------------------------------\n");

        // Task (b): Display people with subordinates and the number of direct reports
        System.out.println(ANSI_BOLD+ANSI_BLUE+"--> People with subordinates and the number of direct reports: <--"+ANSI_BOLD + ANSI_BLACK);
        displayPeopleWithSubordinates(root);
    }

    /**
     * Recursively display all people earning over a certain amount.
     *
     * @param node   The current node in the tree.
     * @param amount The minimum salary amount for filtering.
     */
    private static void displayPeopleWithSalaryOver(DefaultMutableTreeNode node, float amount) {
        Employee employee = (Employee) node.getUserObject();
        if (employee.getSalary() > amount) {
            System.out.println(employee.getForename() + " " + employee.getSurname() +
                    " <-> " + employee.getTitle() + " £" + employee.getSalary());
        }

        for (int i = 0; i < node.getChildCount(); i++) {
            displayPeopleWithSalaryOver((DefaultMutableTreeNode) node.getChildAt(i), amount);
        }
    }

    /**
     * Recursively display people with subordinates and the number of direct reports.
     *
     * @param node The current node in the tree.
     */
    private static void displayPeopleWithSubordinates(DefaultMutableTreeNode node) {
        Employee employee = (Employee) node.getUserObject();
        if (node.getChildCount() > 0) {
            System.out.println(employee.getForename() + " " + employee.getSurname() +
                    " <-> " + employee.getTitle() + " £" + employee.getSalary() +
                    " <-> Director reports: " + node.getChildCount());
            System.out.println("Subordinates -->");
            for (int i = 0; i < node.getChildCount(); i++) {
                Employee subordinate = (Employee) ((DefaultMutableTreeNode) node.getChildAt(i)).getUserObject();
                System.out.println("\t" +
                        subordinate.getForename() + " " + subordinate.getSurname() +
                        " <-> " + subordinate.getTitle() + " £" + subordinate.getSalary());
            }
        }

        for (int i = 0; i < node.getChildCount(); i++) {
            displayPeopleWithSubordinates((DefaultMutableTreeNode) node.getChildAt(i));
        }
    }

}
