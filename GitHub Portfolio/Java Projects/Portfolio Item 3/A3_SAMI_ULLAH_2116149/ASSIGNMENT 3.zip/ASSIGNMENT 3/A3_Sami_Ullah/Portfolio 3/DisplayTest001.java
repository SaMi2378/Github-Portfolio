import javax.swing.tree.DefaultMutableTreeNode;

/**
 * The DisplayTest001 class is responsible for demonstrating the employee hierarchy using recursion and tabulation.
 * It creates employee objects, associates them with tree nodes, and displays the hierarchy in the console window.
 * 
 * @author Sami Ullah
 */
public class DisplayTest001 {

    public static void main(String[] args) {
        // Create employees 
    	Employee mohammedAli = new Employee("Mohammed", "Ali", "Senior Partner", 120000);
        Employee saraJohnson = new Employee("Sara", "Johnson", "Managing Partner", 89000);
        Employee sandraDee = new Employee("Sandra", "Dee", "Partner", 78500);
        Employee fredDibner = new Employee("Fred", "Dibner", "Finance Manager", 67900);
        Employee cleoPatra = new Employee("Cleo", "Patra", "Junior Partner", 45000);
        Employee irfanPatel = new Employee("Irfan", "Patel", "Junior Partner", 45000);
        Employee georgeBush = new Employee("George", "Bush", "Office Manager", 37000);
        Employee harryPotter = new Employee("Harry", "Potter", "Solicitor", 52500);
        Employee ronaldReagan = new Employee("Ronald", "Reagan", "Senior Clerk", 22000);
        Employee simonTemplar = new Employee("Simon", "Templar", "Finance Officer", 18000);
        Employee jacobHeart = new Employee("Jacob", "Heart", "Clerk", 16000);
        Employee barryDwyer = new Employee("Barry", "Dwyer", "Clerk", 16000);
        Employee maryFritz = new Employee("Mary", "Fritz", "Clerk", 16000);
        Employee gordonBrown = new Employee("Gordon", "Brown", "Finance Clerk", 16500);

        // Create tree nodes with employee objects 
        DefaultMutableTreeNode root = new DefaultMutableTreeNode(mohammedAli);
        DefaultMutableTreeNode nodeSaraJohnson = new DefaultMutableTreeNode(saraJohnson);
        DefaultMutableTreeNode nodeSandraDee = new DefaultMutableTreeNode(sandraDee);
        DefaultMutableTreeNode nodeFredDibner = new DefaultMutableTreeNode(fredDibner);
        DefaultMutableTreeNode nodeCleoPatra = new DefaultMutableTreeNode(cleoPatra);
        DefaultMutableTreeNode nodeIrfanPatel = new DefaultMutableTreeNode(irfanPatel);
        DefaultMutableTreeNode nodeGeorgeBush = new DefaultMutableTreeNode(georgeBush);
        DefaultMutableTreeNode nodeHarryPotter = new DefaultMutableTreeNode(harryPotter);
        DefaultMutableTreeNode nodeRonaldReagan = new DefaultMutableTreeNode(ronaldReagan);
        DefaultMutableTreeNode nodeJacobHeart = new DefaultMutableTreeNode(jacobHeart);
        DefaultMutableTreeNode nodeBarryDwyer = new DefaultMutableTreeNode(barryDwyer);
        DefaultMutableTreeNode nodeMaryFritz = new DefaultMutableTreeNode(maryFritz);
        DefaultMutableTreeNode nodeSimonTemplar = new DefaultMutableTreeNode(simonTemplar);
        DefaultMutableTreeNode nodeGordonBrown = new DefaultMutableTreeNode(gordonBrown);

        // Build the hierarchy by adding child nodes to parent nodes 
        root.add(nodeSaraJohnson);
        root.add(nodeSandraDee);
        root.add(nodeFredDibner);
        nodeSaraJohnson.add(nodeCleoPatra);
        nodeSaraJohnson.add(nodeIrfanPatel);
        nodeSaraJohnson.add(nodeGeorgeBush);
        nodeSandraDee.add(nodeHarryPotter);
        nodeSandraDee.add(nodeRonaldReagan);
        nodeGeorgeBush.add(nodeJacobHeart);
        nodeGeorgeBush.add(nodeBarryDwyer);
        nodeRonaldReagan.add(nodeMaryFritz);
        nodeFredDibner.add(nodeSimonTemplar);
        nodeSimonTemplar.add(nodeGordonBrown);


        // Display the hierarchy using recursion and tabulation
        displayHierarchy(root, 0);
    }

    /**
     * Recursive method to display the hierarchy with tabulation.
     *
     * @param node  The current node in the tree.
     * @param depth The depth of the current node in the hierarchy.
     */
    private static void displayHierarchy(DefaultMutableTreeNode node, int depth) {
        Employee employee = (Employee) node.getUserObject();
        System.out.println("\t".repeat(depth) + employee.getForename() + " " + employee.getSurname());

        for (int i = 0; i < node.getChildCount(); i++) {
            displayHierarchy((DefaultMutableTreeNode) node.getChildAt(i), depth + 1);
        }
    }
}
